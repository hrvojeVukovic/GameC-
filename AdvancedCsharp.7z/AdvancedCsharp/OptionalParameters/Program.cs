﻿using System;

namespace OptionalParameters
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintData("Joe", "Duff");
            //PrintData("Joe", 33); //javlja gresku jer na drugom mjestu treba biti string. Ako znamo FName i Age ali ne i LName
            PrintData("Joe", Age: 33);//rjesenje za gornji slucaj
        }



        //Kako nebi overloadali neku funkciju vise puta jer ne znamo hoce li joj biti proslijedjeni svi parametri mozemo te parametre stavit kao optional
        //parametri. Tj zadamo ih defaultne vrijednosti. 
        //Oni parametri koji se zahtjevaju moraju biti postavljeni prvi, tek onda optional parametri tj ne mozemo deklarirat funkciju na sljedeci nacin
        //static void PrintData(string FName=null, string LName, int Age=0)
        static void PrintData(string FName, string LName=null, int Age=0)
        {
            Console.WriteLine("{0} {1} is {2} years old", FName, LName, Age);
        }

        //static void PrintData(string FName, string LName, int Age)
        //{
        //    Console.WriteLine("{0} {1} is {2} years old", FName, LName, Age);
        //}
        //static void PrintData(string FName, string LName)
        //{
        //    PrintData(FName, LName, 0);
        //}
        //static void PrintData(string FName)
        //{
        //    PrintData(FName, null , 0);
        //}
    }
}
