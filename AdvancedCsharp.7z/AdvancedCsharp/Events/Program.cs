﻿using System;

namespace Events
{
    class Program
    {
        static void Main(string[] args)
        {
            var tower = new ClockTower();
            var john = new Person("John", tower);
            var micky = new Person("Micky", tower);
            tower.ChimeFivePM();    //pozivamo ovu funkciju koja u sebi poziva event Chime anjega smo pretplaitili naredbom _tower.Chime += () => Console.WriteLine("{0} heard the clock chime", name);
          
        }
    }
    public class Person
    {
        private string _name;
        private ClockTower _tower;
        public Person(string name, ClockTower tower)
        {
            _name = name;
            _tower = tower;
            _tower.Chime += (object sender, ClockTowerEventArgs args) =>        //ovaj lambda izraz mora odgovarat delegatu kji smo napravili
            { Console.WriteLine("{0} heard the clock chime", name);
                switch (args.Time)
                {
                    case 6:Console.WriteLine("{0} is waking up", _name);
                        break;
                    case 17:
                        Console.WriteLine("{0} is going home", _name);
                        break;
                }
            }; 
        }
    }
    public class ClockTowerEventArgs:EventArgs
    {
        public int Time { get; set; }
    }

    public delegate void ChimeEventHadler(object sender, ClockTowerEventArgs args);    //ovaj delegat podize event
    public class ClockTower
    {
        
        public ClockTower()
        {

        }

        public event ChimeEventHadler Chime;    //event je kao delegat
        public void ChimeFivePM()
        {
            Chime(this, new  ClockTowerEventArgs{ Time=17});
        }

        public void ChimeSixAM()
        {
            Chime(this, new ClockTowerEventArgs { Time = 6 });
        }
    }
}

//1.kada se kreira instanca john klase Person "var john = new Person("John", tower);" koja uzima instancu klase ClockTower tower u konstruktoru
//zatim se poziva funkcija ChimeFivePm klase tower "tower.ChimeFivePM();", a ta funkcija je pretplacena na dogadjaj Chime koji je definiran lambda izrazom i salje mu parametar (this, new  ClockTowerEventArgs{ Time=17})
//izrsava se taj dogadjaj:
/*
 *   { Console.WriteLine("{0} heard the clock chime", name);
                switch (args.Time)
                {
                    case 6:Console.WriteLine("{0} is waking up", _name);
                        break;
                    case 17:
                        Console.WriteLine("{0} is going home", _name);
                        break;
                }
            };
 * */

//1.Dakle prvo smo definirali objekt klase ClockTower "var tower = new ClockTower();" i izvrsio je se samo konstruktor ove klase
//2.definirali smo dva objekta klase Person "var john = new Person("John", tower);" "var micky = new Person("Micky", tower);" i inicijaliziraju se elementi i dogadjaj _tower.Chime ali se jos ne izvrsava
//tek nakon sto se pozove funkcija ChimeFivePM() "tower.ChimeFivePM();" koja je pretplacena na dogadjaj Chime i tek se onda on izvrsava za oba objekta klase Person (john i micky)