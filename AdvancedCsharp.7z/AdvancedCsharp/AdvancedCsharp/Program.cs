﻿namespace AdvancedCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Kada stavimo neku varijablu tipa var, onda tu varijablu moramo inicijalizirat jer kompajler na osnovu date vrijednosti odredjuje
            //tip te varijable. Ako smo prvo u nju (npr firstName) spremili string "John" to znaci da je ona sad tipa string i da u nju ne mozemo 
            //kasnije  pohranit varijablu tipa int, tj ne mozemo prvo stavit var firstName="John"; pa onda firstName=20;
            var firstName = "John"; 
            //var lastName;         //Ne mozemo staviti varijablu tipa var i ne inicijalizirat je, jer kompajler javlja gresku
            var lastName = "";
            var age = 15;
            //age = "Micky"; //nakon sto smo u ovu varijablu spremili podatak tipa int, ne mozemo kasnije u nju spremat string
            //var test = null;    //greska u kompajleru
            var test = (string)null;    //dozvoljeno

        }
    }
}
