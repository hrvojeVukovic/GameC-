﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AonymousTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            var people = new List<Person>
            {
                new Person {Name="John", LastName="Jackson", Age=22 },
                new Person {Name="Bob", LastName="Jackson", Age=43 },
                new Person {Name="John", LastName="Smith", Age=25},
                new Person {Name="Patric", LastName="Jackson", Age=32 },
                new Person {Name="Brad", LastName="Williams", Age=19 }
            };
            //kada radimo sa objektima koji imaju puno propertija (klasa Person sada ima 10ak), mozemo kreirati anonimne tipove sa proizvoljnim propertijima

            var result = from p in people
                         where p.Age < 40 && p.Name == "John"
                         orderby p.Age descending
                         //select p;    
                         select new { FName = p.Name, LName = p.LastName };      //kreira se novi objekt sa propertijima FName i LName i takav objekt se vraca u result
            //te sada varijabla result postaje lista objekta sa propertijima FName i LName                

            //buduci da result vise nije lista tipa Person nego novo kreiranog objekta, zato u foreach petlji ne mozemo stavit
            //foreach (Person pers in result)
            foreach (var pers in result)
            {
                Console.WriteLine("{0} {1}", pers.FName, pers.LName);
            }
           

        }
    }

    public class Person
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public int MyProperty1 { get; set; }
        public int MyProperty2 { get; set; }
        public int MyProperty3 { get; set; }
        public int MyProperty4 { get; set; }
        public int MyProperty5 { get; set; }
        public int MyProperty6 { get; set; }
        public int MyProperty7 { get; set; }
        public int MyProperty8 { get; set; }



    }
}
