﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            var john = new Person { Name = "John", Age = 19 };
            john.YearsOld();
            var micky = new Person { Name = "Mciky", Age=23 };
            micky.SayHelloTo(john);

        }
    }

    public static class Extensions
    { 
        public static void YearsOld(this Person person)
        {
            Console.WriteLine("{0} is {1} years old", person.Name, person.Age);
        }

        public static void SayHelloTo(this Person person, Person person2)
        {
            Console.WriteLine("{0} says hello to {1}.", person.Name, person2.Name);
        }
    }
}

/*EXTENSIONS METHODS
 * Sluze nam u slucaju da npr ako nemamo pristup nekoj klasi tj ne mozemo je sami mijenjat ali bi nam bila jako korisna neka metoda u njoj koja ne postoji
 * Mi mozemo sami kreirat tu metodu iako nemamo pristup toj klasi. Kreiramo Extension metodu koja mora bit kreirana u static klasi i metoda mora biti static
 * te joj prvi argument mora biti ta klasa za koju kreiramo ovu extension metodu i to sa kljucnom rijeci this
 * */
