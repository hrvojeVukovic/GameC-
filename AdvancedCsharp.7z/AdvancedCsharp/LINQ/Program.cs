﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            var people = new List<Person>
            {
                new Person {Name="John", LastName="Jackson", Age=22 },
                new Person {Name="Bob", LastName="Jackson", Age=43 },
                new Person {Name="John", LastName="Smith", Age=25},
                new Person {Name="Patric", LastName="Jackson", Age=32 },
                new Person {Name="Brad", LastName="Williams", Age=19 }

            };

            //var result = from p in people                   //varijabla p (proizvoljno ime) predstavlja objekt tipa Person jer je people List<Person> 
            //             where p.Age < 40 && p.Name == "John"   //uvijet
            //             orderby p.Age descending         //sortiramo ih prema godinama u opadajucem nizu
            //             select p;                          //ako je uvijet zadovoljen objekt p se vraca u varijablu result, pa je i ona List<Person>

            //foreach (Person pers in result)
            //{
            //    Console.WriteLine("{0} {1}", pers.Name, pers.LastName);
            //}


            var result = from p in people
                         where p.Age <40
                         orderby p.Age descending
                         group p by p.LastName; //grupiramo ih po prezimenu
            //Kada imamo group funkciju onda se mora maket naredba select

            //Kada se radi grupiranje onda imamo key tj properti po kojem je radjeno grupiranje i imamo podatke predstavljene s tim kljucem
            foreach (var item in result)
            {
                Console.WriteLine(item.Key+" "+item.Count());
                foreach(var pod in item)
                {
                    Console.WriteLine("\t{0} {1}", pod.Name, pod.LastName);
                }
               
            }
            
           
        }
    }

    public class Person
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

    }
}
