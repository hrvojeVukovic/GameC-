﻿using System;
using System.Linq;
using System.Reflection;

namespace Attributes
{
    class Program
    {

        //Atributi su klasa koja nam sluzi za dodijeljivanje metapodataka nasem kodu
        //Bilo koji atribut koji kreiramo mozemo dodijeliti bilo cemu(klasi, propertiju, funkciji ...)
        static void Main(string[] args)
        {
            var types = from t in Assembly.GetExecutingAssembly().GetTypes()
                        where t.GetCustomAttributes<SampleAttribute>().Count() > 0
                        select t;

            foreach(var t in types)
            {
                Console.WriteLine(t.Name);      //Ipisuje samo klasu Test
                foreach(var p in t.GetProperties())
                {
                    Console.WriteLine(p.Name);  //ispisuje IntValue jer je to jedini propertij klase Test
                }
            }
            
        }

        
    }

    //Assembly.GetExecutingAssembly-pogledaj u ovom assembliu tj u ovom projektu "Attributes"
    //GetTypes()- dohvati sve tipove klasa
    //t.GetCustomAttributes<SampleAttribute>()-dohvati samo one koje imaju SampleAttribute
    //select t-spremi u t
    //Pronadji sve klase u ovom assembliu-"Attribute" koje za atribut imaju klasu Sample, tj  samo klasa Test jer NoAttribute nema za atribut Sample klasu
    //a i Sample klasa nema samu sebe za atribut



    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property)]    //ovo znaci da je mogu samo naslijediti klase, ako bi u test klasi iznad propertija stavili [Sample]
                                                                            //onda bi u zagradi trebali stavit (AttributeTargets.Class | AttributeTargets.Property)
    public class SampleAttribute:Attribute
    {

    }


    [Sample]        //ovo znaci da ce test klasa imati mogucnost dodjeljivanja metapodataka klase Sample
    public class Test
    {
        public int IntValue { get; set; }
        public void Method() { }
    }

    public class NoAttribute
    {
       
    }
}
