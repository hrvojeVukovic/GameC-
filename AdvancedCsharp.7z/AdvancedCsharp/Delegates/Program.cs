﻿using System;

namespace Delegates
{
    class Program
    {
        delegate void MyDelegate1();
        delegate void MyDelegate2(string n);

        delegate void Operation(int n);
        static void Main(string[] args)
        {
            MyDelegate1 del = new MyDelegate1(SayHello);
            del.Invoke();

            //Moze se i ovako pozvati delegat
            MyDelegate1 del1a = SayHello;
            del1a();

            //prosljedivanje delgata kao parametra u funkciju
            Test(del1a);

            //delegat na funkciju sa parametrom
            MyDelegate2 del2 = SayHelloWithParametar;
            del2("Johan");

            //delegat je jednak funkciji koja ce vratiti taj delegat
            MyDelegate2 del2a = GiveMeMyDelegate();
            del2a("Peter");


            //KADA GOD ZELIMO PROSLIJEDIT JEDNU FUNKCIJU KAO PARAMETAR DRUGOJ ONDA TO RADIMO PREKO DELEGATA


            //kreiranje delegata na funkciju, i zatim izvrsavanje preko funkcije koja za argumente ima int i delegat
            Operation operationDouble = Double;
            ExecuteOperation(2, operationDouble);

            Operation operationTriple = Triple;
            ExecuteOperation(5, operationTriple);


            //mozemo da i ne krreiramo novu instanu delegata

            Operation operation = Double;
            operation += Triple;
            ExecuteOperation(4, operation);
        }

        static void SayHello()
        {
            Console.WriteLine("Hello");
        }

        static void SayHelloWithParametar(string name)
        {
            Console.WriteLine("Hello "+name);
        }


        //fukncija koja prima delegat kao parametar i izvrsava ga
        static void Test(MyDelegate1 delegat)
        {
            delegat();
        }

        //funkcija koja vraca MyDelegate2
        static MyDelegate2 GiveMeMyDelegate()
        {
            return new MyDelegate2(SayHelloWithParametar);
        }

        static void Double(int num)
        {
            Console.WriteLine("{0}*2={1}", num, num * 2);
        }

        static void Triple(int num)
        {
            Console.WriteLine("{0}*3={1}", num, num * 3);
        }

        //funkcija koja prima int i deleaget za parametre, te potom izvrsava jednu od funkcija(Double ili Triple)
        static void ExecuteOperation(int num, Operation operr)
        {
            operr(num);
        }
    }
}
