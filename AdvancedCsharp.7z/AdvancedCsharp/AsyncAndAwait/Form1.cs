﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncAndAwait
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CallBigImportantMethod();
            label1.Text = "Waiting...";
        }

        private async void CallBigImportantMethod()
        {
            var result = await BigLongImportantMethodAsync("Andrew");
            label1.Text = result;
             
        }
        private Task<string> BigLongImportantMethodAsync(string name)
        {
            return Task.Factory.StartNew(() => BigLongImportantMethod(name));
        }

        private string BigLongImportantMethod(string name)
        {
            Thread.Sleep(5000);
            return "Hello " + name;
        }

        //Metoda u kojoj koristimo rijec AWAIT mora biti oznacena kao ASYNC metoda
        //AWAIT i ASYNC oznacavaju poziciju koda od koje bi se program trebao nastaviti nakon sto se Task ili Thread obave
        //Dakle kada se klikne na button on ce pozvati metodu  CallBigImportantMethod(); koja ce prvo pokusat izvrsiti naredbu "var result = await BigLongImportantMethodAsync("Andrew");"
        //ali posto se u njoj koristi kljucna rijec AWAIT to znaci da ce sljedeca naredba  "label1.Text = result;" pricekati dok se Taks i Thread ne izvrse
        //Ali paralelno dok se ceka njihovo izvrsenje, naredba "label1.Text = "Waiting...";" ne ceka na izvrsenje nego se odvija paralelno.

        //1."var result = await BigLongImportantMethodAsync("Andrew");" poziva metodu tu metodu i salje joj string "Andrew" kao parametar
        //Metoda BigLongImportantMethodAsync treba vratit Task<string>. 
        //2."return Task.Factory.StartNew(() => BigLongImportantMethod(name));"  ova naredba ce vratiti Task<varijabla> i poziva funkciju BigLongImportantMethod
        //cija ce povratna vrijednost biti varijabla. A buduci da BigLongImportantMethod vraca string onda ce ova naredba vratit Task<string> sto i odgovara
        //povratnoj vrijednosti funkcije BigLongImportantMethodAsync.
        //3."Thread.Sleep(5000);" kada se pozove funkcija  BigLongImportantMethod i krene izvrsavanje naredbe "Thread.Sleep(5000);" ovo zaustavlja program ovdje na 5 sekundi

        //------------------------------------------------------------------------------------------------------------------


        private void button2_Click(object sender, EventArgs e)
        {

            if (hScrollBar1.Value == 0)
            {
                CallScrolBar();
                label2.Text = "Waiting on the scrollbar";
                button2.Text = "Restart Scrollbar";
                button2.Enabled = false;
            }
            else
            {
                CallScrolBar();
                label2.Text = "ScrollBar is restarting";
                button2.Enabled = false;

            }

        }

        private async void CallScrolBar()
        {
            var result = await CallScrolBaAsync();
            label2.Text = result;

        }

        private Task<string> CallScrolBaAsync()
        {
            return Task.Factory.StartNew(() => hScrollBar1_Scroll());

        }

        private string hScrollBar1_Scroll()
        {
            if (hScrollBar1.Value == 0)
            {
                while (hScrollBar1.Value < 100)
                {
                    Thread.Sleep(100);
                    hScrollBar1.Value += 1;
                }

                button2.Enabled = true;
                return "ScrollBar is on the end";
            }
            else
            {
                while (hScrollBar1.Value > 0)
                {
                    Thread.Sleep(100);
                    hScrollBar1.Value -= 1;
                }

                button2.Enabled = true;
                button2.Text = "Scroll bar to the end";
                return "ScrollBar is on the start";
            }



        }
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
