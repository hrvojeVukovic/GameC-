﻿using System;
using System.Linq;
using System.Reflection;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            var assemb = Assembly.GetExecutingAssembly();   //dohvaca assembli
            Console.WriteLine(assemb.FullName); //ispisuje puni naziv naseg assemblija tj naseg projekta

            var types = assemb.GetTypes();  //dohvaca sve klase u assembliju
            foreach(var type in types)
            {
                Console.WriteLine("Type: " + type.Name);    //ispisuje nam naziv klasa

                var prop = type.GetProperties();    //dohvaca propertije klase
                foreach(var pr in prop)
                {
                    Console.WriteLine("\tProperty: " + pr.Name+" PropertyType: "+pr.PropertyType);    //ispisuje propertije klase i njihove tipove(int,string)
                }

                var methods = type.GetMethods();    //dohvaca metode klase
                foreach(var meth in methods)
                {
                    Console.WriteLine("Method: " + meth.Name);  //ispisuje imena metoda
                    //prve di metode koje ispise su metode get i set vezane za propertije
                    //zadnje 4 metode su vezane za objekt koji nasljudjuje svaka klasa
                }
            }

            var sample = new Sample { Name = "John", Age = 12 }; //objekt klase i inicijaliziramo propertije
            var sampleType = typeof(Sample);    //dohvacamo typ klase sample
            var nameProperty = sampleType.GetProperty("Name");  //dohvacamo propertij po naziuv "Name", tj u varijablu nameProperty sprema propertij klase Sample koji se zove Name
            Console.WriteLine("Property: " + nameProperty.GetValue(sample));//ispisujemo vrijednost propertija Name od objekta sample

            var mymethod = sampleType.GetMethod("Method");//dohvaca meodu po nazivu Method
            mymethod.Invoke(sample, null);//izvrsava methodu

            //ako zelimo dohvatit sve tipove koji imaju MyClassAttribute klasu za Attribut onda cemo napravit sljedece

            var tip = assemb.GetTypes().Where(t => t.GetCustomAttributes<MyClassAttribute>().Count() > 0);

            foreach (var t in tip)
                Console.WriteLine(t.Name);
        }
    }

    [MyClass]
    public class Sample
    {
        public string Name { get; set; }
        public int Age { get; set; }
        [MyMethod]
        public void Mtehod()
        {
            Console.WriteLine("Hello from Method");
        }
    }

    [AttributeUsage(AttributeTargets.Class)]
    public class MyClassAttribute:Attribute
    {

    }

    [AttributeUsage(AttributeTargets.Method)]
    public class MyMethodAttribute:Attribute
    {

    }
}
