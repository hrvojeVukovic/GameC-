﻿using System;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ako imamo klase koje imaju slicne propertije ali razlicitog tipa podataka, umjesto da kreiramo vise klasa mozemo kreirat jednu klasu tipa
            //Result i prilikom inicijaliziranja proslijedit joj tip podatka

            var result1 = new Result<int, int> { firstName = "John", Data1 = 15, Data2 = 10 };
            Console.WriteLine(result1.firstName + " " + result1.Data1 + " " + result1.Data2);


            var result2 = new Result<string, string> { firstName = "John", Data1 = "London", Data2 = "A10" };
            Console.WriteLine(result2.firstName + " " + result2.Data1 + " " + result2.Data2);

            var result3 = new Result<bool, bool> { firstName = "John", Data1 = false, Data2 = true };
            Console.WriteLine(result3.firstName + " " + result3.Data1 + " " + result3.Data2);


            Console.WriteLine("-------------------------------\nDrugi dio\n-------------------------------");
            //-----------------------------------------------------------------------
            /*Drugi dio
             * Mozemo kreirat klasu i u njoj funkciju koja ce kao parametar priamt objekt klase Result kako bi ispisviali njezine propertije
             * u cilju smanjivanja redundanice koda 
             */

            var helper = new ResultPrint();
            helper.Print(result1);
            helper.Print(result2);
            helper.Print(result3);

        }
    }


    public class Result<D1, D2>
    {
        public string firstName { get; set; }
        public D1 Data1 { get; set; }
        public D2 Data2 { get; set; }
    }

    //Umjesto da kreiramo ovakve tri klase moze se kreirat samo jedna klasa tipa Result
    //public class KlasaInt
    //{
    //    public string firstName { get; set; }
    //    public int Data1 { get; set; }
    //    public int Data2 { get; set; }
    //}

//public class KlasaString
//{
//    public string firstName { get; set; }
//    public string Data1 { get; set; }
//    public string Data2 { get; set; }
//}

//public class KlasaBool
//{
//    public string firstName { get; set; }
//    public bool Data1 { get; set; }
//    public bool Data2 { get; set; }
//}


//-----------------------------------------------------------------------
//Drugi dio
    public class ResultPrint
    {
        public void Print<T1,T2>(Result<T1,T2> result)
        {
        Console.WriteLine(result.firstName + " " + result.Data1 + " " + result.Data2);
        }
    }


    //Da smo kreiralu funkciju kao vamo dolje, onda bi smo mogli proslijediti samo objekt result2
    //public class ResultPrint
    //{
    //    public void Print(Result<string, string> result)
    //    {
    //        Console.WriteLine(result.firstName + " " + result.Data1 + " " + result.Data2);
    //    }
    //}


    //Isto tako ne bi mogli kreirati funkciju na sljedeci nacin, tj kompajler bi javio gresku
    // public void Print(Result<T1,T2> result)
}
