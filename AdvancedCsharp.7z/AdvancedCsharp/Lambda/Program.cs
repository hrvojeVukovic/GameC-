﻿using System;


namespace Lambda
{

    class Program
    {
        delegate void Operation(int num);

        delegate string Operation2(int num1, int num2);
        static void Main(string[] args)
        {
            //prvi primjer
            Operation op = num => { Console.WriteLine("{0}x2={1}", num, num * 2); };
            op(3);
            Console.WriteLine();
            op = x => { for (int i = 0; i < x; i++) { Console.WriteLine("{0}*{1}={2}", i, x, i * x); } };
            op(4);

            //drugi primjer
            Operation2 op2=(x,y)=> {  { return x.ToString()+"*"+y.ToString()+"="+(x*y).ToString(); }  } ;
            Console.WriteLine(op2(5, 6).ToString());



            //Func i Action delegati

            Console.WriteLine("\nFunc i Action delegati");

            //prvi primjer
            Action<int> action=num=>{ Console.WriteLine("{0}x2={1}", num, num * 2); };
            action(3);

            //drugi primjer
            Func<int, int, string> func=(x,y) => { { return x.ToString() + "*" + y.ToString() + "=" + (x * y).ToString(); } };
            Console.WriteLine( func(5, 6));

        }

        
    }
        
}
